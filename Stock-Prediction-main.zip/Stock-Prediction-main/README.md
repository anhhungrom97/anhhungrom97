# Stock-Prediction
test.py is to test your model without training ( make sure to adjust the name of variables )
stock.py is to take data, build a model, train model, test model and make prediction
crypto.py is the same to stock.py but for cryptocurrency
Feel free to tune the numbers in the code

test.py là để test model mà không cần train (điều chỉnh các biến lại cho phù hợp)
stock.py là để lấy data, build model machine learning cơ bản, train model, test model và dự đoán
crypto.py cũng tương tự stock nhưng để áp dụng với tiền ảo
Bạn thể điều chỉnh các số theo ý thích

