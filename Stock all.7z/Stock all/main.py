# -*- coding: utf-8 -*-
"""
Created on Sun May 22 13:54:17 2022

@author: HOANG
"""

import pandas as pd
import yfinance as yf
from yahoofinancials import YahooFinancials
import investpy
import pandas as pd
import datetime as dt

from sklearn.preprocessing import MinMaxScaler

import numpy as np
from pandas_datareader import data as pdr
import yfinance as yfin
import vnquant.DataLoader as dl
yfin.pdr_override()
# Load data
start = '2022-01-01'
end = dt.datetime.now().strftime("%Y-%m-%d")
dates= start + ' to ' + end
dfmack=pd.read_csv("C:\\Users\\HOANG\\Desktop\\Python\\Ma CK Viet Nam.csv")
dfmack=pd.DataFrame(dfmack)
#dfmack=dfmack.loc[dfmack['SAN']=='HNX']
listck=dfmack['Ma CK'].values.tolist()

stock_final = pd.DataFrame()
for i in listck:  
    
    # print the symbol which is being downloaded
    #print( str(listck.index(i)) + str(' : ') + i, sep=',', end=',', flush=True)  
    
    try:
        # download the stock price 
        stock = []
        stock = dl.DataLoader(i, start,end, data_source='VND', minimal=True)
        data = stock.download()
        data.columns = data.columns.droplevel(1)
        
        print(data.head())

        
        # append the individual stock prices 
        if len(data) == 0:
            None
        else:
            data['name']=i
         
            stock_final = stock_final.append(data, ignore_index=True)
    except Exception:
        None

stock_final=pd.DataFrame(stock_final) 
stock_final=stock_final.groupby(['name']).mean()
stock_final['day']=dates
stock_final=stock_final.sort_values(by='volume', ascending=False)

stock_final.to_csv("C:\\Users\\HOANG\\Desktop\\Python\\all\\"f"all.csv")